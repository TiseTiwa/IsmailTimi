import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion'
import {
  FiGithub, FiExternalLink, FiMenu, FiX, FiMail,
  FiPlay, FiPause, FiDownload, FiArrowRight
} from 'react-icons/fi'
import {
  SiReact, SiNodedotjs, SiMongodb, SiJavascript, SiHtml5,
  SiCss, SiPython, SiFigma, SiVite, SiVercel, SiPostman,
  SiExpress, SiGit, SiTailwindcss
} from 'react-icons/si'
import { FaLinkedin, FaInstagram, FaWhatsapp } from 'react-icons/fa'

// ─── Data ────────────────────────────────────────────────────────────────────

const NAV_LINKS = ['Home','About','Skills','Projects','Experience','Contact']

const TITLES = ['Full-Stack Web Developer','Software Engineer','B.Sc Computer Science Student']

const SKILLS = [
  { icon: SiHtml5,      label: 'HTML',       color: '#E34F26', yrs: '3+' },
  { icon: SiCss,       label: 'CSS',        color: '#1572B6', yrs: '3+' },
  { icon: SiJavascript, label: 'JavaScript', color: '#F7DF1E', yrs: '2+' },
  { icon: SiReact,      label: 'React',      color: '#61DAFB', yrs: '2+' },
  { icon: SiNodedotjs,  label: 'Node.js',    color: '#339933', yrs: '2+' },
  { icon: SiExpress,    label: 'Express',    color: '#aaa',    yrs: '2+' },
  { icon: SiMongodb,    label: 'MongoDB',    color: '#47A248', yrs: '2+' },
  { icon: SiPython,     label: 'Python',     color: '#3776AB', yrs: '1+' },
  { icon: SiFigma,      label: 'Figma',      color: '#F24E1E', yrs: '2+' },
  { icon: SiVite,       label: 'Vite',       color: '#646CFF', yrs: '2+' },
  { icon: SiVercel,     label: 'Vercel',     color: '#fff',    yrs: '2+' },
  { icon: SiPostman,    label: 'Postman',    color: '#FF6C37', yrs: '2+' },
  { icon: SiGit,        label: 'Git',        color: '#F05032', yrs: '2+' },
  { icon: SiTailwindcss,label: 'Tailwind',   color: '#06B6D4', yrs: '1+' },
]

const PROJECTS = [
  {
    id: 1, cat: 'fullstack',
    title: 'Rielshotit — Photographer Portfolio',
    desc: 'Portfolio site for a professional photographer/videographer showcasing works and booking services.',
    stack: ['React','Vite','Tailwind'],
    demo: 'https://riel-s-portfolio.vercel.app', github: '',
  },
  {
    id: 2, cat: 'fullstack',
    title: 'Tidoy Airbnb Clone',
    desc: 'Modern Airbnb-inspired landing page and booking UI built with React + Vite.',
    stack: ['React','Vite','CSS'],
    demo: 'https://tidoy-main-seven.vercel.app/', github: '',
  },
  {
    id: 3, cat: 'frontend',
    title: 'E-Commerce Dessert App',
    desc: 'Product listing, cart management, and order confirmation — vanilla JS, HTML, and CSS.',
    stack: ['JavaScript','HTML','CSS'],
    demo: 'https://tise-tiwa-e-commerce-order-desert-a.vercel.app/',
    github: 'https://github.com/TiseTiwa/E-Commerce-Order-Desert-App',
  },
  {
    id: 4, cat: 'frontend',
    title: 'Bible Quiz App',
    desc: 'Interactive browser quiz with scoring, high-score persistence, sound effects, and multiple flows.',
    stack: ['JavaScript','HTML','CSS'],
    demo: 'https://tise-tiwa-s-bible-quiz.vercel.app',
    github: 'https://github.com/TiseTiwa/Tise-Tiwa-s-Bible-Quiz',
  },
  {
    id: 5, cat: 'fullstack',
    title: 'Goal Tracker App',
    desc: 'React + Vite SPA for setting and tracking personal goals with a clean component architecture.',
    stack: ['React','Vite','Node.js'],
    demo: 'https://goal-web-front-end.vercel.app',
    github: 'https://github.com/TiseTiwa/Goal-web-Front-End',
  },
  {
    id: 6, cat: 'frontend',
    title: 'World Info App',
    desc: 'Browse and explore country data from around the world with search and filter functionality.',
    stack: ['React','Vite','REST API'],
    demo: 'https://world-info-app-eight.vercel.app',
    github: 'https://github.com/TiseTiwa/World-Info-App',
  },
]

const EXPERIENCE = [
  {
    year: '2022–2025',
    title: 'B.Sc Computer Science',
    org: 'University',
    desc: 'Studied data structures, algorithms, software engineering principles, databases, and computer networks.',
  },
  {
    year: '2023',
    title: 'TechStudio Bootcamp',
    org: 'TechStudio Academy',
    desc: 'Intensive hands-on web development bootcamp covering full-stack JavaScript, React, Node.js and MongoDB.',
  },
  {
    year: '2023',
    title: 'Udemy Web Dev Certification',
    org: 'Udemy',
    desc: 'Completed a 60-hour course on modern web development including HTML, CSS, JavaScript and React.',
  },
  {
    year: '2024–Present',
    title: 'Freelance Full-Stack Developer',
    org: 'Self-employed',
    desc: 'Building production-grade web apps for clients — portfolios, e-commerce, and SaaS dashboards.',
  },
]

// ─── Typewriter ───────────────────────────────────────────────────────────────

function Typewriter({ titles }) {
  const [index, setIndex] = useState(0)
  const [displayed, setDisplayed] = useState('')
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const current = titles[index]
    let timeout

    if (!deleting && displayed.length < current.length) {
      timeout = setTimeout(() => setDisplayed(current.slice(0, displayed.length + 1)), 60)
    } else if (!deleting && displayed.length === current.length) {
      timeout = setTimeout(() => setDeleting(true), 1800)
    } else if (deleting && displayed.length > 0) {
      timeout = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 35)
    } else if (deleting && displayed.length === 0) {
      setDeleting(false)
      setIndex((i) => (i + 1) % titles.length)
    }

    return () => clearTimeout(timeout)
  }, [displayed, deleting, index, titles])

  return (
    <span className="font-medium" style={{ color: '#ff1f3d' }}>
      {displayed}
      <span className="cursor" />
    </span>
  )
}

// ─── Navbar ───────────────────────────────────────────────────────────────────

function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const scrollTo = (id) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' })
    setOpen(false)
  }

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? 'rgba(5,5,5,0.85)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(255,255,255,0.06)' : 'none',
      }}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <motion.div
          className="text-xl font-bold tracking-widest"
          style={{ fontFamily: 'Space Grotesk, sans-serif', letterSpacing: '0.12em' }}
        >
          <span style={{ color: '#ff1f3d' }}>ISMAIL</span>
          <span style={{ color: '#fff' }}> TIMI</span>
        </motion.div>

        {/* Desktop */}
        <ul className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(link => (
            <li key={link}>
              <button
                onClick={() => scrollTo(link)}
                className="text-sm text-gray-400 hover:text-white transition-colors duration-200 relative group"
                style={{ fontWeight: 500, letterSpacing: '0.04em', background: 'none', border: 'none', cursor: 'pointer' }}
              >
                {link}
                <span className="absolute -bottom-1 left-0 w-0 h-px group-hover:w-full transition-all duration-300"
                  style={{ background: '#ff1f3d' }} />
              </button>
            </li>
          ))}
        </ul>

        {/* Mobile hamburger */}
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden text-white"
          style={{ background: 'none', border: 'none', cursor: 'pointer' }}
        >
          {open ? <FiX size={22} /> : <FiMenu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden"
            style={{ background: 'rgba(5,5,5,0.96)', borderTop: '1px solid rgba(255,255,255,0.06)' }}
          >
            <ul className="px-6 py-6 flex flex-col gap-5">
              {NAV_LINKS.map(link => (
                <li key={link}>
                  <button
                    onClick={() => scrollTo(link)}
                    className="text-gray-300 hover:text-white text-base"
                    style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────────

function Hero() {
  const videoRef = useRef(null)
  const [playing, setPlaying] = useState(true)
  const { scrollY } = useScroll()
  const yText = useTransform(scrollY, [0, 400], [0, -80])
  const opacity = useTransform(scrollY, [0, 300], [1, 0])

  const togglePlay = () => {
    if (!videoRef.current) return
    if (playing) { videoRef.current.pause(); setPlaying(false) }
    else { videoRef.current.play(); setPlaying(true) }
  }

  return (
    <section id="home" style={{ position: 'relative', height: '100vh', overflow: 'hidden' }}>
      {/* Background video */}
      <video
        ref={videoRef}
        autoPlay loop playsInline
        style={{
          position: 'absolute', inset: 0,
          width: '100%', height: '100%',
          objectFit: 'cover',
          opacity: 0.55,
        }}
      >
        <source src="/hero.webm" type="video/webm" />
        <source src="/hero.mp4" type="video/mp4" />
      </video>

      {/* Gradient overlays */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(to right, rgba(5,5,5,0.92) 40%, rgba(5,5,5,0.4) 100%)',
      }} />
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 20% 80%, rgba(255,31,61,0.12) 0%, transparent 60%)',
      }} />
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: '200px',
        background: 'linear-gradient(to top, #050505, transparent)',
      }} />

      {/* Content */}
      <motion.div
        style={{ y: yText, opacity }}
        className="absolute bottom-0 left-0 px-8 md:px-16 pb-20 max-w-2xl"
      >
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="text-sm mb-4 tracking-widest uppercase"
          style={{ color: '#ff1f3d', fontWeight: 600 }}
        >
          ✦ Available for work
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-5xl md:text-7xl font-extrabold leading-none mb-4"
          style={{ fontFamily: 'Space Grotesk, sans-serif', letterSpacing: '-0.02em' }}
        >
          Hi, I'm<br />
          <span style={{ color: '#ff1f3d' }}>Ismail Timi</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="text-lg md:text-xl mb-8 text-gray-400"
        >
          <Typewriter titles={TITLES} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.6 }}
          className="flex items-center gap-4 flex-wrap"
        >
          <a
            href="/ismailcv.pdf" download
            className="flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300"
            style={{
              background: '#ff1f3d',
              color: '#fff',
              boxShadow: '0 0 20px rgba(255,31,61,0.5)',
            }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = '0 0 40px rgba(255,31,61,0.8)'}
            onMouseLeave={e => e.currentTarget.style.boxShadow = '0 0 20px rgba(255,31,61,0.5)'}
          >
            <FiDownload size={15} /> Download CV
          </a>
          <button
            onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
            className="flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold transition-all duration-300"
            style={{
              background: 'rgba(255,255,255,0.06)',
              border: '1px solid rgba(255,255,255,0.12)',
              color: '#fff',
              cursor: 'pointer',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(255,31,61,0.5)'; e.currentTarget.style.boxShadow = '0 0 20px rgba(255,31,61,0.2)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'; e.currentTarget.style.boxShadow = 'none' }}
          >
            View Projects <FiArrowRight size={15} />
          </button>
        </motion.div>
      </motion.div>

      {/* Play/Pause button — bottom right */}
      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.5, duration: 0.5 }}
        onClick={togglePlay}
        className="absolute bottom-8 right-8 w-12 h-12 rounded-full flex items-center justify-center glass transition-all duration-300"
        style={{ cursor: 'pointer', border: '1px solid rgba(255,31,61,0.3)' }}
        onMouseEnter={e => e.currentTarget.style.boxShadow = '0 0 24px rgba(255,31,61,0.6)'}
        onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
        aria-label={playing ? 'Pause video' : 'Play video'}
      >
        {playing ? <FiPause size={16} color="#ff1f3d" /> : <FiPlay size={16} color="#ff1f3d" />}
      </motion.button>
    </section>
  )
}

// ─── Section wrapper with reveal ──────────────────────────────────────────────

function Section({ id, children, className = '' }) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true) }, { threshold: 0.1 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <section
      id={id}
      ref={ref}
      className={`max-w-6xl mx-auto px-6 md:px-12 py-24 ${className}`}
      style={{ opacity: visible ? 1 : 0, transform: visible ? 'none' : 'translateY(40px)', transition: 'opacity 0.8s ease, transform 0.8s ease' }}
    >
      {children}
    </section>
  )
}

function SectionLabel({ children }) {
  return (
    <p className="text-xs font-bold tracking-widest uppercase mb-3" style={{ color: '#ff1f3d' }}>
      {children}
    </p>
  )
}

function SectionTitle({ children }) {
  return (
    <h2 className="text-4xl md:text-5xl font-extrabold mb-12" style={{ fontFamily: 'Space Grotesk, sans-serif', letterSpacing: '-0.02em' }}>
      {children}
    </h2>
  )
}

// ─── About ────────────────────────────────────────────────────────────────────

function About() {
  const stats = [
    { val: '3+', label: 'Years Building' },
    { val: '10+', label: 'Projects Shipped' },
    { val: '14+', label: 'Technologies' },
    { val: '2+', label: 'Certifications' },
  ]

  return (
    <Section id="about">
      <SectionLabel>Who I am</SectionLabel>
      <SectionTitle>About Me</SectionTitle>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div>
          <p className="text-gray-400 text-lg leading-relaxed mb-6">
            I'm a Computer Science graduate and full-stack developer who turns ideas into
            production-grade web applications. I care deeply about performance, clean code,
            and experiences that feel effortless to use.
          </p>
          <p className="text-gray-400 leading-relaxed mb-8">
            Currently exploring mobile development to broaden my craft. Open to remote
            roles, freelance projects, and long-term collaborations.
          </p>

          <div className="flex gap-4">
            {[
              { href: 'https://github.com/TiseTiwa', icon: FiGithub },
              { href: 'https://linkedin.com/in/ismail-timileyin', icon: FaLinkedin },
              { href: 'https://www.instagram.com/tisetiwa_fit/', icon: FaInstagram },
              { href: 'https://wa.me/2347073558984', icon: FaWhatsapp },
            ].map(({ href, icon: Icon }) => (
              <a key={href} href={href} target="_blank" rel="noreferrer"
                className="w-10 h-10 rounded-full glass flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300 glow-hover"
                style={{ border: '1px solid rgba(255,255,255,0.08)' }}>
                <Icon size={17} />
              </a>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {stats.map(({ val, label }) => (
            <div key={label}
              className="glass glow-hover rounded-2xl p-6 text-center transition-all duration-300"
              style={{ border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="text-3xl font-extrabold mb-1" style={{ color: '#ff1f3d', fontFamily: 'Space Grotesk, sans-serif' }}>
                {val}
              </div>
              <div className="text-sm text-gray-500">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  )
}

// ─── Skills ───────────────────────────────────────────────────────────────────

function Skills() {
  return (
    <Section id="skills" style={{ paddingTop: 0 }}>
      <SectionLabel>What I work with</SectionLabel>
      <SectionTitle>Skills & Tools</SectionTitle>

      <div className="flex flex-wrap gap-3">
        {SKILLS.map(({ icon: Icon, label, color, yrs }, i) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, scale: 0.85 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.04, duration: 0.4 }}
          >
            <div className="skill-pill" style={{ border: '1px solid rgba(255,255,255,0.08)', color: '#ccc' }}>
              <Icon size={16} style={{ color }} />
              <span>{label}</span>
              <span style={{ color: '#555', fontSize: '11px' }}>{yrs}yr</span>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  )
}

// ─── Projects ─────────────────────────────────────────────────────────────────

function Projects() {
  const [filter, setFilter] = useState('all')
  const cats = ['all', 'fullstack', 'frontend']

  const filtered = filter === 'all' ? PROJECTS : PROJECTS.filter(p => p.cat === filter)

  return (
    <Section id="projects">
      <SectionLabel>What I've built</SectionLabel>
      <SectionTitle>Projects</SectionTitle>

      {/* Filter tabs */}
      <div className="flex gap-3 mb-10 flex-wrap">
        {cats.map(c => (
          <button key={c} onClick={() => setFilter(c)}
            className="px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 capitalize"
            style={{
              background: filter === c ? '#ff1f3d' : 'rgba(255,255,255,0.04)',
              color: filter === c ? '#fff' : '#888',
              border: `1px solid ${filter === c ? '#ff1f3d' : 'rgba(255,255,255,0.08)'}`,
              cursor: 'pointer',
              boxShadow: filter === c ? '0 0 16px rgba(255,31,61,0.4)' : 'none',
            }}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((p, i) => (
          <motion.article
            key={p.id}
            layout
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.4 }}
            className="glass rounded-2xl p-6 flex flex-col gap-4 glow-hover transition-all duration-300 group"
            style={{ border: '1px solid rgba(255,255,255,0.08)' }}
          >
            <div className="flex items-start justify-between">
              <span className="text-xs font-bold tracking-widest uppercase px-2 py-1 rounded-full"
                style={{ background: 'rgba(255,31,61,0.12)', color: '#ff1f3d' }}>
                {p.cat}
              </span>
            </div>

            <h3 className="text-base font-bold text-white leading-snug">{p.title}</h3>
            <p className="text-sm text-gray-500 leading-relaxed flex-1">{p.desc}</p>

            <div className="flex flex-wrap gap-2">
              {p.stack.map(t => (
                <span key={t} className="text-xs px-2 py-1 rounded-md"
                  style={{ background: 'rgba(255,255,255,0.05)', color: '#888', border: '1px solid rgba(255,255,255,0.06)' }}>
                  {t}
                </span>
              ))}
            </div>

            <div className="flex gap-3 pt-2">
              {p.demo && (
                <a href={p.demo} target="_blank" rel="noreferrer"
                  className="flex items-center gap-1 text-xs font-semibold transition-colors duration-200"
                  style={{ color: '#ff1f3d' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#ff5269'}
                  onMouseLeave={e => e.currentTarget.style.color = '#ff1f3d'}>
                  <FiExternalLink size={13} /> Live Demo
                </a>
              )}
              {p.github && (
                <a href={p.github} target="_blank" rel="noreferrer"
                  className="flex items-center gap-1 text-xs font-semibold text-gray-500 hover:text-white transition-colors duration-200">
                  <FiGithub size={13} /> GitHub
                </a>
              )}
            </div>
          </motion.article>
        ))}
      </div>
    </Section>
  )
}

// ─── Experience ───────────────────────────────────────────────────────────────

function Experience() {
  return (
    <Section id="experience">
      <SectionLabel>My journey</SectionLabel>
      <SectionTitle>Experience & Education</SectionTitle>

      <div className="relative timeline-line pl-10 flex flex-col gap-10">
        {EXPERIENCE.map((e, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className="relative"
          >
            {/* Dot */}
            <div className="absolute -left-10 top-1 w-4 h-4 rounded-full flex items-center justify-center"
              style={{ background: '#ff1f3d', boxShadow: '0 0 12px rgba(255,31,61,0.7)' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-white" />
            </div>

            <div className="glass rounded-xl p-5 glow-hover transition-all duration-300"
              style={{ border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="text-xs font-bold mb-1" style={{ color: '#ff1f3d' }}>{e.year}</div>
              <div className="font-bold text-white mb-0.5">{e.title}</div>
              <div className="text-xs text-gray-500 mb-3">{e.org}</div>
              <p className="text-sm text-gray-400 leading-relaxed">{e.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  )
}

// ─── Contact ──────────────────────────────────────────────────────────────────

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const [status, setStatus] = useState('idle') // idle | sending | sent | error

  const handleChange = e => setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('sending')
    // Simulate send (replace with EmailJS / backend)
    await new Promise(r => setTimeout(r, 1200))
    setStatus('sent')
    setForm({ name: '', email: '', subject: '', message: '' })
    setTimeout(() => setStatus('idle'), 4000)
  }

  const inputStyle = {
    width: '100%',
    background: 'rgba(255,255,255,0.03)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '12px',
    padding: '14px 16px',
    color: '#e8e8e8',
    fontSize: '14px',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
    fontFamily: 'Inter, sans-serif',
  }

  const onFocus = e => { e.target.style.borderColor = 'rgba(255,31,61,0.5)'; e.target.style.boxShadow = '0 0 16px rgba(255,31,61,0.15)' }
  const onBlur  = e => { e.target.style.borderColor = 'rgba(255,255,255,0.08)'; e.target.style.boxShadow = 'none' }

  return (
    <Section id="contact">
      <SectionLabel>Get in touch</SectionLabel>
      <SectionTitle>Let's Work Together</SectionTitle>

      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <p className="text-gray-400 leading-relaxed mb-8">
            I'm open to freelance projects, full-time remote roles, and interesting collaborations.
            If you have an idea you'd like to bring to life, let's talk.
          </p>

          <div className="flex flex-col gap-4">
            {[
              { icon: FiMail, label: 'Email', val: 'ismailkoya04@gmail.com', href: 'mailto:ismailkoya04@gmail.com' },
              { icon: FaWhatsapp, label: 'WhatsApp', val: '+234 707 355 8984', href: 'https://wa.me/2347073558984' },
            ].map(({ icon: Icon, label, val, href }) => (
              <a key={label} href={href} target="_blank" rel="noreferrer"
                className="flex items-center gap-4 glass rounded-xl p-4 glow-hover transition-all duration-300"
                style={{ border: '1px solid rgba(255,255,255,0.08)', textDecoration: 'none' }}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: 'rgba(255,31,61,0.12)' }}>
                  <Icon size={16} style={{ color: '#ff1f3d' }} />
                </div>
                <div>
                  <div className="text-xs text-gray-500">{label}</div>
                  <div className="text-sm text-white font-medium">{val}</div>
                </div>
              </a>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-4">
            <input required name="name" value={form.name} onChange={handleChange}
              placeholder="Your name" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
            <input required type="email" name="email" value={form.email} onChange={handleChange}
              placeholder="Email address" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
          </div>
          <input required name="subject" value={form.subject} onChange={handleChange}
            placeholder="Subject" style={inputStyle} onFocus={onFocus} onBlur={onBlur} />
          <textarea required name="message" value={form.message} onChange={handleChange}
            placeholder="Your message..." rows={5}
            style={{ ...inputStyle, resize: 'vertical' }} onFocus={onFocus} onBlur={onBlur} />

          <button type="submit" disabled={status === 'sending' || status === 'sent'}
            className="px-8 py-3 rounded-full font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2"
            style={{
              background: status === 'sent' ? '#16a34a' : '#ff1f3d',
              color: '#fff',
              cursor: status === 'sending' ? 'wait' : 'pointer',
              boxShadow: `0 0 20px ${status === 'sent' ? 'rgba(22,163,74,0.4)' : 'rgba(255,31,61,0.4)'}`,
              border: 'none',
            }}>
            {status === 'idle' && <><FiMail size={14} /> Send Message</>}
            {status === 'sending' && 'Sending…'}
            {status === 'sent' && '✓ Message Sent!'}
          </button>
        </form>
      </div>
    </Section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer style={{ borderTop: '1px solid rgba(255,255,255,0.06)', padding: '40px 24px', textAlign: 'center' }}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm" style={{ color: '#555' }}>
          © {new Date().getFullYear()} <span style={{ color: '#ff1f3d', fontWeight: 600 }}>Ismail Timi</span>. All Rights Reserved.
        </div>
        <div className="flex items-center gap-4">
          {[
            { href: 'https://github.com/TiseTiwa', icon: FiGithub },
            { href: 'https://linkedin.com/in/ismail-timileyin', icon: FaLinkedin },
            { href: 'https://www.instagram.com/tisetiwa_fit/', icon: FaInstagram },
            { href: 'https://wa.me/2347073558984', icon: FaWhatsapp },
            { href: 'mailto:ismailkoya04@gmail.com', icon: FiMail },
          ].map(({ href, icon: Icon }) => (
            <a key={href} href={href} target="_blank" rel="noreferrer"
              className="text-gray-600 hover:text-white transition-colors duration-200">
              <Icon size={17} />
            </a>
          ))}
        </div>
      </div>
    </footer>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <>
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Projects />
      <Experience />
      <Contact />
      <Footer />
    </>
  )
}
